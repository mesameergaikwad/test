﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data;
using System.Data.SqlClient;
using CrystalDecisions.CrystalReports.Engine;
using System.Threading.Tasks;
using CrystalDecisions.Shared;
using System.Drawing.Printing;
using System.Web.UI.WebControls;
 

namespace CrystalReport_CS
{
    public partial class Form1 : Form
    {
        PrintDocument printDocument = new PrintDocument();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CustomerReport crystalReport = new CustomerReport();
            Customers dsCustomers = GetData();
            crystalReport.SetDataSource(dsCustomers);
            this.crystalReportViewer1.ReportSource = crystalReport;
            this.crystalReportViewer1.RefreshReport();

            printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);
        }

        private Customers GetData()
        {
            string constr = "Data Source=DESKTOP-abcdef\\SQLEXPRESS;Initial Catalog=TEST;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT EmployeeID,Name,Address,PhoneNumber,EmployeeType FROM Employees"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (Customers dsCustomers = new Customers())
                        {
                            sda.Fill(dsCustomers, "Employees");
                            return dsCustomers;
                        }
                    }
                }
            }
        }

        private void print_Click(object sender, EventArgs e)
        {
            PrintDialog printDialog = new PrintDialog();
            printDialog.Document = printDocument;

            if (printDialog.ShowDialog() == DialogResult.OK)
            {
                printDocument.Print();
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            string textToPrint = "Hello, this is a test print from C#";

            Font printFont = new Font("Arial", 12);
            float x = 100;
            float y = 100;

            e.Graphics.DrawString(textToPrint, printFont, Brushes.Black, x, y);
        }


    }
}
